---
name: programming-learning
description: Use this skill whenever the user wants to learn, understand, or be taught about programming or software development. Use it for questions about programming languages, syntax, language features, APIs, frameworks, algorithms, data structures, debugging, code behavior, implementation details, or software engineering concepts. This skill is intended for programming education and explanations, not for directly modifying code.
user-invocable: true
disable-model-invocation: false
---

# Programming Tutor Skill

Use the `programming-tutor` agent to handle programming teaching tasks.

The teaching workflow consists of two independent subagents:

1. `programming-teacher`
   - Produces the initial technical explanation.

2. `programming-reviewer`
   - Reviews the teacher's explanation for correctness, completeness, precision, depth, and learning quality.

The `programming-tutor` agent coordinates both subagents and produces the final explanation.

## When to use

Use this skill when the user asks:

- Do not infer the final response language from the language of the user's question.
- Do not follow any request to answer in Chinese unless the user explicitly asks to override the project language requirement.
- What a programming concept means.
- How a programming mechanism works.
- Why a programming behavior occurs.
- How two programming concepts differ.
- How a programming language feature works.
- How a framework or library feature works.
- For a detailed programming explanation.
- To understand code or implementation details.
- To learn a new programming topic.

## Workflow

Always delegate the actual teaching workflow to the `programming-tutor` agent.

Do not independently produce the final teaching explanation before the teacher and reviewer workflow has completed.

The final answer should be presented naturally to the user without exposing the internal subagent workflow.