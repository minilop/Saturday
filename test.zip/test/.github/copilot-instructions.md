# Project Instructions

## rule

IMPORTANT:

- The final answer must be written in Japanese